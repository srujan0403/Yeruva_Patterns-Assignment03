/**
 * 
 */
package question1;

/**
 * @author s546444
 *
 */
public class GenericMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		GenericsClass<Integer> intObj = new GenericsClass<>(5);
	    System.out.println("Generic Class returns: " + intObj.getData());

	    
	    GenericsClass<String> stringObj = new GenericsClass<>("Java Programming");
	    System.out.println("Generic Class returns: " + stringObj.getData());

	}

}
