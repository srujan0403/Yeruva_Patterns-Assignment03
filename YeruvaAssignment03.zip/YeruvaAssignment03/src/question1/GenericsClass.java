package question1;

public class GenericsClass<Srujan> {

	private Srujan data;

	  public GenericsClass(Srujan data) {
	    this.data = data;
	  }

	  
	  public Srujan getData() {
	    return this.data;
	  }
}
