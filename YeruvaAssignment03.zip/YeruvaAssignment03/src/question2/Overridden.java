package question2;

class Overridden1
{
    protected void method()
    {
        System.out.println("Hello");
    }
}
 
public class Overridden2 extends Overridden1 {
 
    
    void method()
    {
        System.out.println("Hello");
    }
 
    public static void main(String args[])
    {
    	Overridden2 or = new Overridden2();
        or.method();
    }
}