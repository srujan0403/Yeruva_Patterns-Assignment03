package question8;

public class Q8 {
	   public static void main(String[] args) {
	      try {
	         System.out.println("This is Try Block");
	      } finally {
	         System.out.println("This is Finally Block");
	      }
	   }
	}
