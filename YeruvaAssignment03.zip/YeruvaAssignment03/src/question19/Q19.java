package question19;




public class Q19 extends Thread {
	  public static void main(String[] args) {
		  Q19 thread = new Q19();
	    thread.start();
	    System.out.println("Implements runnable interface");
	  }
	  public void run() {
	    System.out.println("extends thread");
	  }
	}