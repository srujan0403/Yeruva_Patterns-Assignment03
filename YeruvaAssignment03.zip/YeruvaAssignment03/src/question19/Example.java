package question19;

public class Example implements Runnable {
	  public void run() {
	    System.out.println("Implements runnable interface");
	  }
	}

