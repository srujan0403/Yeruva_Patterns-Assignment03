package question19;



public class Example2 extends Thread {
	  public void run() {
	    System.out.println("extends thread");
	  }
	}