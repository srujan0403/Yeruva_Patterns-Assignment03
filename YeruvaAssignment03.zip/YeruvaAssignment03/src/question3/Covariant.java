package question3;

public class Covariant {
	
	Covariant get()
	{return this;}    
	}    
	    
	class Covariant2 extends Covariant{    
	Covariant2 get(){return this;}    
	void message(){System.out.println("this is an example for covariant return type");}    
	    
	 

}
