package question17;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.ConcurrentHashMap;
public class Q17 {
	public static void main(String[] args) {
		ArrayList<Integer> list = new ArrayList<Integer>();
		list.add(1);
		list.add(2);
		Iterator<Integer> it = list.iterator();
		while (it.hasNext()) {
			Integer integer = (Integer) it.next();
			list.add(3);
		}
		ConcurrentHashMap<String, Integer> map = new ConcurrentHashMap<String, Integer>();
	    map.put("ONE", 1);
        map.put("TWO", 2);
         Iterator<String> itr = map.keySet().iterator();
         while (itr.hasNext())
        {
            String key = (String) itr.next();
             System.out.println(key+" : "+map.get(key));
             map.put("FIVE", 5);
        }
	}
}