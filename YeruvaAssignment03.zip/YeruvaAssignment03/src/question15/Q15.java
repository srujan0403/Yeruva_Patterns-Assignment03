package question15;
import java.util.*; 
public class Q15 {  
     public static void main(String args[]) 
    { 
        
        HashMap<Integer,String> cities = new HashMap<Integer,String>();
 
        
        cities.put(1, "Newyork");
        cities.put(4, "Chicago");
                
        for (Map.Entry entry : cities.entrySet()) {
            System.out.println(entry.getKey() + " - " + entry.getValue());
        }
        
        Hashtable<Integer,String> oceans = new Hashtable<Integer,String>();
             
        oceans.put(1, "Indian");
        oceans.put(4, "Pacific");    
        for (Map.Entry entry : oceans.entrySet()) {
            System.out.println(entry.getKey() + " - " + entry.getValue());
        }
    }  
}