package question25;
import java.util.*;
import java.util.stream.Collectors;
public class Q25 {
	public static void main(String[] args) {
		List<Integer> arrayList = new ArrayList<>();
		arrayList.add(1);
		arrayList.add(2);
		arrayList.add(3);
		arrayList.add(4);
		
		arrayList.forEach((i)->{
			i*=2;
			System.out.print(i + " ");
		});
		System.out.println("");
		List<Integer> updatedList = arrayList.stream().filter(i-> i<3).collect(Collectors.toList());
		System.out.println(updatedList);
		
		
	}
}
