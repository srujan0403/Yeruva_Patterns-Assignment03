package question7;

public class Q7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int number;
	      final public Q7(){
	         number = 30;
	}

}

}
