package question5;

public class StringExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		StringBuffer s1 = new StringBuffer();
	    StringBuffer sb1 = new StringBuffer("Hello");
	    System.out.println(sb1);
	    sb1.append(" World");
	    System.out.println(sb1);
	    
	    StringBuilder s2 = new StringBuilder();
	    StringBuilder sb2 = new StringBuilder("Patterns");
	    System.out.println(sb2);
	    sb2.append(" Frameworks");
	    System.out.println(sb2);
	}

}
