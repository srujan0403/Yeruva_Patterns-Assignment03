package question21;
import java.io.*;
public class Q21 {
	   public static void main(String [] args) {
	      Employee e = new Employee();
	      e.name = "Srujan";
	      e.address = "203 W";
	      e.SSN = 999999999;
	      e.number = 919;
	      
	      try {
	         FileOutputStream fileOut =
	         new FileOutputStream("sample.txt");
	         ObjectOutputStream out = new ObjectOutputStream(fileOut);
	         out.writeObject(e);
	         out.close();
	         fileOut.close();
	         System.out.printf("Serialized data is saved");
	      } catch (IOException i) {
	         i.printStackTrace();
	      }
	   }
	}