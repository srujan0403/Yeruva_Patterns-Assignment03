package question12;
public class Q12 {
	int field1 = 1;
	final int field2 = 2;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			System.out.println("try block");
			throw new Exception();
		} catch (Exception e) {
			System.out.println("catch block");
		} finally {
			System.out.println("finally block");
		}
		Q12 object = new Q12();
		object = null;
		System.gc();
	}
	protected void finalize() throws Throwable {
		System.out.println("finalize method");
		super.finalize();
	}
}
