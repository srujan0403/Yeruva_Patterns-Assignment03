package Question14;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;
class Q14
{
	public static void main (String[] args)
	{
		List<String> list =
		Collections.synchronizedList(new ArrayList<String>());
		list.add("NOrth");
		list.add("West");
		synchronized(list)
		{
		Iterator it = list.iterator();

			while (it.hasNext())
				System.out.println(it.next());
		}
		CopyOnWriteArrayList<String> t1 = new CopyOnWriteArrayList<String>();
    t1.add("Missouri");
    t1.add("State");
     Iterator<String> it = t1.iterator();
    while (it.hasNext())
        System.out.println(it.next());
	}
}
