package question18;

public class Q18 extends Thread{  
	 public void run(){  
	   System.out.println("Started");  
	 }  
	 public static void main(String args[]){  
		 Q18 t1=new Q18();  
	  t1.start();  
	  t1.start();  
	 }  
	}  