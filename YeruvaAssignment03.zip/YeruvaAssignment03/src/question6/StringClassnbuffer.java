package question6;

public class StringClassnbuffer
{
    public static void main(String[] args) 
    {

        String s = new String("North ");
        
        s += "West";
        System.out.println(s);

        StringBuffer sb = new StringBuffer("Missouri ");
        sb.append("State University");
        System.out.println(sb);
    }
}