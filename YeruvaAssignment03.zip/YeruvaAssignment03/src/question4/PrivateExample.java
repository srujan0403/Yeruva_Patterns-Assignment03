package question4;

class PrivateExample {
	private void print1() {
		System.out.println("Super class");
	}

	static void print2() {
		System.out.println("Sub class");
	}
}
