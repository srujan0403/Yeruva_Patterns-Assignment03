package question4;

public class Main extends PrivateExample {

	void print2() {
		System.out.println("overrided");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PrivateExample pse = new Main();
	      pse.print1();
	      pse.print2();
	}

}
