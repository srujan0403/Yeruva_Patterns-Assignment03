package Question13;
import java.util.*;
public class Q13 {
	public static void main(String args[]) {
		List<String> al = new ArrayList<String>();
		al.add("Srujan");
		al.add("Yeruva");
		Iterator itr = al.iterator();
		while (itr.hasNext()) {
			System.out.println(itr.next());
		}
		
		Vector<String> v=new Vector<String>();  
		  v.add("Yeruva");  
		  v.addElement("Srujan"); 
		   
		  Enumeration e=v.elements();  
		  while(e.hasMoreElements()){  
		   System.out.println(e.nextElement());  
		  }  
	}
}
